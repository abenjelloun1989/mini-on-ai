# Claude Code HTML Presentation Prompt Pack

> Build a prompt-pack product titled 'Claude Code HTML Presentation Prompt Pack' for freelancers, consultants, and developers who want to generate beautiful single-file HTML slide decks using AI coding agents like Claude Code. The pack should contain 25 ready-to-use prompts organized into 5 sections: (1) Deck Structure & Layout Prompts — prompts for setting up 5 distinct slide layouts (hero, data, quote, timeline, comparison); (2) Visual Theme Prompts — prompts for applying dark, light, corporate, minimal, and creative themes with CSS variables; (3) Content-Type Prompts — prompts for case studies, project proposals, sales decks, and status reports; (4) Interactivity & Animation Prompts — prompts for adding swipe navigation, scroll effects, and WebGL/canvas hero backgrounds; (5) Client Delivery Prompts — prompts for exporting single-file output, adding client branding, and generating a PDF-ready version. Each prompt should include the full text, a brief usage note, and a 'remix tip'. Tone is practical and efficient. Price point $19. This sells because HTML deck generation via Claude Code is exploding (3,200+ stars in days) and no Gumroad product addresses it yet.

---

## Prompts (20 total)

### 1. Hero Slide Layout with Animated Background

**Use case:** Opening slide for product launches or keynote presentations

```
Build a single-file HTML presentation opening slide for [PRODUCT NAME] targeting [TARGET AUDIENCE]. The hero slide must include: a full-viewport layout with a CSS animated gradient background using these brand colors [PRIMARY COLOR] and [SECONDARY COLOR], a large bold headline in [FONT NAME or 'system sans-serif'], a one-line subheadline, a CTA button with hover state, and a subtle particle or floating-shape animation using vanilla JavaScript and canvas. All styles must be scoped inside a <style> tag and all scripts inside a <script> tag. No external dependencies. Output a complete, self-contained HTML file that opens correctly in any modern browser.
```

### 2. Data Visualization Slide with Live Charts

**Use case:** Quarterly reviews, investor updates, or performance dashboards

```
Generate a single-file HTML slide for presenting key metrics for [COMPANY OR PROJECT NAME]. The slide must contain: a two-column grid layout, three animated bar charts built with pure CSS and JavaScript (no Chart.js or external libraries), each chart displaying [METRIC 1], [METRIC 2], and [METRIC 3] with values [VALUE 1], [VALUE 2], [VALUE 3], a headline that reads '[SLIDE HEADLINE]', and a data source footnote. Bars should animate in on load with a smooth ease-in transition. Use a color palette of [COLOR 1], [COLOR 2], and [COLOR 3]. Output a complete self-contained HTML file with all CSS and JS inline.
```

### 3. Pull Quote Slide with Typography Focus

**Use case:** Testimonial slides, thought leadership decks, or brand storytelling

```
Create a single-file HTML presentation slide featuring a bold pull quote for [SPEAKER NAME or COMPANY]. Requirements: full-bleed background in [BACKGROUND COLOR], the quote text '[QUOTE TEXT]' displayed in a large serif or display font at minimum 48px, attributed to [ATTRIBUTION NAME and TITLE], a decorative oversized quotation mark rendered in CSS behind the text, subtle fade-in animation on load, and a slide number indicator in the bottom right corner. The layout must be vertically and horizontally centered. Output must be a complete, self-contained HTML file with no external dependencies.
```

### 4. Vertical Timeline Slide for Milestones

**Use case:** Project roadmaps, company history slides, or sprint retrospectives

```
Build a single-file HTML slide displaying a vertical timeline of milestones for [PROJECT OR COMPANY NAME]. Include exactly [NUMBER] timeline entries with dates [DATE LIST] and milestone labels [MILESTONE LIST]. Design requirements: alternating left-right layout for each milestone card, a vertical connecting line in [ACCENT COLOR], icons represented as colored circles with initials or emoji, scroll-triggered fade-in animation for each card using IntersectionObserver, and a slide title '[TIMELINE TITLE]' at the top. Use a [LIGHT or DARK] background. All styles and scripts must be inline. Output a complete self-contained HTML file that works without internet access.
```

### 5. Side-by-Side Comparison Slide

**Use case:** Vendor comparisons, strategy decisions, or feature matrix slides

```
Generate a single-file HTML comparison slide contrasting [OPTION A NAME] versus [OPTION B NAME] for [TARGET AUDIENCE]. Layout: two equal columns separated by a vertical divider line, each column with a header, a list of [NUMBER] bullet points ([OPTION A POINTS] and [OPTION B POINTS]), a color-coded badge indicating [RECOMMENDED OPTION] as the recommended choice, and subtle hover effects on each column. Use a professional color scheme with [BRAND COLOR] as the accent. Add a slide headline '[COMPARISON HEADLINE]' and a footer note '[FOOTER TEXT]'. All CSS and JavaScript must be self-contained in a single HTML file with no external dependencies.
```

### 6. Dark Theme Full Deck with CSS Variables

**Use case:** Tech demos, developer-facing pitches, or evening conference talks

```
Create a complete single-file HTML slide deck with [NUMBER] slides for [PRESENTATION TITLE] using a dark professional theme. Use CSS custom properties (variables) defined in :root for all colors: --bg-primary: #0f0f0f, --bg-secondary: #1a1a1a, --text-primary: #ffffff, --text-secondary: #a0a0a0, --accent: [ACCENT COLOR]. The deck must include: keyboard navigation (arrow keys), a slide counter, smooth CSS transitions between slides, slides for [LIST SLIDE TOPICS], and a consistent header/footer on each slide. All content, styles, and navigation script must be in one HTML file. No frameworks. No CDN links. Output the complete file.
```

### 7. Light Minimal Corporate Theme Deck

**Use case:** Client-facing consulting decks or executive briefings

```
Build a single-file HTML presentation deck for [COMPANY NAME] using a clean light minimal corporate theme. Define all design tokens as CSS variables: --primary: [BRAND COLOR], --surface: #ffffff, --surface-alt: #f8f9fa, --text: #1a1a2e, --border: #e0e0e0, --radius: 8px. Include [NUMBER] slides covering [SLIDE TOPICS]. Each slide must have: consistent top navigation bar with company name '[COMPANY NAME]' and logo placeholder, section labels, clean typography using system-ui font stack, and arrow-key navigation. Slides should feel like a premium consulting deck. All code inline in one HTML file. No external resources.
```

### 8. Creative Gradient Theme with Bold Typography

**Use case:** Agency pitches, creative portfolios, or brand reveal presentations

```
Generate a single-file HTML presentation for [BRAND OR PROJECT NAME] with a creative, bold visual theme targeting [TARGET AUDIENCE]. Design requirements: each slide uses a unique gradient background from a cohesive palette ([COLOR 1], [COLOR 2], [COLOR 3], [COLOR 4]), headlines in a bold 700-weight font at 56-72px with mix-blend-mode overlays for contrast, body text in a clean sans-serif, large decorative background numbers or shapes on each slide, and slide-to-slide transitions using CSS clip-path or transform animations triggered by arrow keys. Include [NUMBER] slides on the topic of [PRESENTATION TOPIC]. Output a complete self-contained HTML file.
```

### 9. Case Study Deck with Problem-Solution Flow

**Use case:** Sales proposals, portfolio presentations, or post-project reviews

```
Create a complete single-file HTML case study presentation for [CLIENT NAME] by [YOUR COMPANY NAME]. The deck must follow this narrative structure across slides: (1) Client Overview — industry [INDUSTRY], size [COMPANY SIZE]; (2) The Challenge — [PROBLEM DESCRIPTION]; (3) Our Approach — [SOLUTION DESCRIPTION] with a 3-step process visual; (4) Results — animated metric counters showing [RESULT 1], [RESULT 2], [RESULT 3]; (5) Testimonial quote from [QUOTE TEXT] by [PERSON NAME, TITLE]; (6) Next Steps CTA. Use a professional [LIGHT or DARK] theme with [BRAND COLOR] as accent. Metric counters must animate from 0 to final value on slide entry. Full inline HTML file, no dependencies.
```

### 10. Project Proposal Deck with Budget Breakdown

**Use case:** Agency or freelancer proposal decks sent to prospective clients

```
Build a single-file HTML project proposal presentation for [PROJECT NAME] to be delivered to [CLIENT NAME]. Include these slides: (1) Executive Summary with project goal '[PROJECT GOAL]'; (2) Scope of Work with [NUMBER] deliverables listed as icon-cards; (3) Timeline — a horizontal Gantt-style bar chart showing phases [PHASE LIST] over [DURATION]; (4) Investment — a styled pricing table with tiers [TIER 1 NAME: PRICE], [TIER 2 NAME: PRICE], [TIER 3 NAME: PRICE] with the middle tier highlighted as recommended; (5) About Us — team grid with [NUMBER] placeholder avatar cards; (6) Call to Action with contact details [CONTACT INFO]. Use a clean corporate theme. All code inline. No external dependencies. Output complete HTML.
```

### 11. Sales Deck with Objection-Handling Slides

**Use case:** Sales calls, demo follow-ups, or self-serve sales pages as decks

```
Generate a single-file HTML sales deck for [PRODUCT OR SERVICE NAME] targeting [BUYER PERSONA]. Structure: (1) Hook slide — bold pain-point headline '[PAIN POINT]'; (2) Problem agitation — 3-card grid of customer struggles; (3) Solution reveal — product/service name '[PRODUCT NAME]' with tagline '[TAGLINE]'; (4) How It Works — 3-step horizontal flow diagram built in CSS; (5) Social proof — logos grid with [NUMBER] placeholder client logos and a testimonial; (6) Objection handlers — tabbed interface with 3 tabs: [OBJECTION 1], [OBJECTION 2], [OBJECTION 3] and answers; (7) Pricing — clean card with price [PRICE] and feature list; (8) Close — CTA with urgency element. Full inline HTML. Keyboard navigation. No external dependencies.
```

### 12. Weekly Status Report Slide Deck

**Use case:** PM status updates, client reporting, or sprint review meetings

```
Create a single-file HTML weekly status report deck for [PROJECT NAME] — week of [DATE RANGE]. Include these slides: (1) Status Overview — traffic-light RAG indicators (Red/Amber/Green) for [STATUS ITEM 1], [STATUS ITEM 2], [STATUS ITEM 3]; (2) Completed This Week — checkmark list of [COMPLETED ITEMS]; (3) In Progress — kanban-style card layout showing [IN PROGRESS ITEMS] with percentage bars; (4) Blockers & Risks — red-bordered alert cards for [BLOCKER LIST]; (5) Next Week Plan — numbered priority list of [NEXT ACTIONS]; (6) Key Metrics — sparkline-style mini charts using SVG for [METRIC 1], [METRIC 2]. Use a clean light theme. RAG indicators must be color-coded circles. All inline. No external dependencies. Output complete HTML.
```

### 13. Touch and Swipe Navigation Deck

**Use case:** Mobile-first presentations, tablet demos, or client self-service decks

```
Build a single-file HTML presentation on the topic of [PRESENTATION TOPIC] for [AUDIENCE] with full touch and swipe navigation support. Requirements: [NUMBER] content slides, touch event listeners (touchstart, touchend) detecting left/right swipe gestures with a minimum swipe threshold of 50px, keyboard arrow key navigation as fallback, a dot indicator at the bottom showing current slide position, smooth CSS slide transitions using transform: translateX, and a subtle swipe hint animation on the first slide showing a hand icon swiping. All content must be readable on mobile screens (minimum 375px width). Use a [THEME: dark/light/minimal] theme. Fully self-contained HTML file. No frameworks. No CDN.
```

### 14. Scroll-Triggered Animation Presentation

**Use case:** Scrollytelling reports, product one-pagers, or narrative pitches

```
Generate a single-file HTML long-scroll presentation for [TOPIC] with scroll-triggered animations. Layout: vertical scrolling document with [NUMBER] full-viewport sections. Each section must animate its content in as it enters the viewport using IntersectionObserver (threshold: 0.2). Animation types: Section 1 — fade-up text; Section 2 — staggered card reveal (delay each card by 100ms); Section 3 — count-up number animation for metrics [METRIC 1: VALUE], [METRIC 2: VALUE]; Section 4 — horizontal slide-in from alternating sides; Section 5 — scale-up with opacity. Include a sticky navigation bar with section links and smooth scroll. Use [THEME COLOR PALETTE]. All code self-contained. Output complete HTML.
```

### 15. WebGL Canvas Hero Background Slide

**Use case:** High-impact opening slides for tech or innovation-focused presentations

```
Create a single-file HTML presentation hero slide for [BRAND NAME] with a WebGL canvas background animation. Using vanilla WebGL (no Three.js, no external libraries), render an animated background of [CHOOSE ONE: floating particles / wave mesh / aurora gradient / geometric grid] using [PRIMARY COLOR] and [SECONDARY COLOR]. Overlay: centered slide content with headline '[HEADLINE TEXT]', subheadline '[SUBHEADLINE]', and a primary CTA button '[BUTTON LABEL]'. The canvas must resize on window resize. WebGL shader code must be included inline as script tags with type='x/vertex-shader' and type='x/fragment-shader'. Fallback: if WebGL is unavailable, show a CSS gradient background. Complete self-contained HTML file. No external dependencies.
```

### 16. Single-File Export with Embedded Assets

**Use case:** Preparing final deliverables that work offline or via email attachment

```
Take the following HTML presentation code [PASTE YOUR HTML HERE] and convert it into a truly portable single-file HTML document. Tasks: (1) Find any external font references and replace them with system font stack equivalents or inline the font-face using base64-encoded WOFF2 data for [FONT NAME] fetched from Google Fonts; (2) Convert any external image src attributes to inline base64 data URIs (use placeholder colored SVG rectangles for images that cannot be encoded); (3) Remove all CDN script tags and replace with inline equivalents or vanilla JS alternatives; (4) Minify all CSS and JavaScript while keeping HTML readable; (5) Add an HTML comment at the top: '<!-- Standalone build — no internet required -->'. Output the complete modified HTML file.
```

### 17. Client Branding Injection Prompt

**Use case:** Whitelabeling template decks for multiple clients quickly

```
Apply the following client branding to the HTML presentation template below [PASTE TEMPLATE HTML]. Branding specification: Company name '[CLIENT COMPANY NAME]', Primary color [HEX 1], Secondary color [HEX 2], Accent color [HEX 3], Logo: use the text '[CLIENT INITIALS]' styled as a CSS-only logo mark in a colored square (since no image file is available), Headline font '[FONT NAME or system-serif]', Body font '[FONT NAME or system-sans-serif]', Tagline '[CLIENT TAGLINE]'. Instructions: (1) Replace all CSS variable values in :root with the client colors; (2) Replace all placeholder company names with '[CLIENT COMPANY NAME]'; (3) Add the CSS logo mark in the header of every slide; (4) Update the footer copyright text to '[CURRENT YEAR] [CLIENT COMPANY NAME]. All rights reserved.'; (5) Output the complete rebranded HTML file.
```

### 18. PDF-Ready Print Stylesheet Version

**Use case:** Delivering PDF versions of HTML decks to clients or for email

```
Modify the following HTML presentation [PASTE HTML HERE] to add a complete print/PDF stylesheet. Requirements: add a <style media='print'> block that (1) displays all slides sequentially (remove any JavaScript show/hide logic by setting all slide elements to display:block !important); (2) adds page-break-after: always to each slide element; (3) sets slide dimensions to 25.4cm x 14.29cm (16:9 at 96dpi) using @page rule with zero margins; (4) converts any dark backgrounds to white and dark text to #1a1a1a for ink efficiency unless the user specifies to keep dark theme; (5) hides navigation buttons, dot indicators, and interactive controls; (6) adds a print button in the live view: a fixed-position button calling window.print() styled in [ACCENT COLOR]. Output the complete modified HTML file ready for File > Print > Save as PDF in Chrome.
```

### 19. Interactive Tabbed Content Slide

**Use case:** Detailed feature slides, multi-scenario demos, or FAQ slides

```
Build a single-file HTML presentation slide featuring an interactive tabbed content section for [TOPIC]. Specifications: [NUMBER] tabs with labels [TAB LABEL LIST], each tab panel containing [DESCRIBE CONTENT TYPE: e.g., bullet list / image + text / data table / step-by-step process]. Tab behavior: clicking a tab label switches the visible panel with a smooth 200ms fade transition, active tab has [ACCENT COLOR] underline and bold text, tab panels use smooth height animation. Surrounding slide layout: slide title '[SLIDE TITLE]' at the top, optional context paragraph '[CONTEXT TEXT]', and a slide number. Use a [LIGHT or DARK] background with [BRAND COLOR] accent. All logic in vanilla JavaScript. Fully self-contained HTML file. No frameworks or CDN links.
```

### 20. Full 10-Slide Deck from Outline

**Use case:** Rapidly generating a complete deck from any structured outline

```
Generate a complete, professional, single-file HTML slide deck from the following outline. Presentation title: '[PRESENTATION TITLE]'. Presenter: '[PRESENTER NAME]'. Organization: '[ORGANIZATION]'. Target audience: [TARGET AUDIENCE]. Slide outline: [PASTE YOUR SLIDE OUTLINE HERE — e.g., 'Slide 1: Title, Slide 2: Problem, Slide 3: Market Size...']. Design requirements: use a [DARK or LIGHT] theme with [PRIMARY COLOR] and [SECONDARY COLOR] as accents, consistent header with presentation title on all slides except the title slide, arrow-key and on-screen button navigation, a progress bar at the top showing slide completion percentage, slide counter in format 'X / 10' bottom right, smooth slide transitions using CSS opacity and transform. All slides must have unique layouts suited to their content type (title, data, text, quote, etc.). Complete self-contained HTML. No external dependencies. Output the full file.
```
