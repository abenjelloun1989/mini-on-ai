# Shopify Product Description Packs for E-Commerce

> 30 prompts for e-commerce store owners to write SEO-optimized, benefit-focused product descriptions that convert browsers into buyers.

---

## Prompts (25 total)

### 1. Core Benefit-Focused Product Description

**Use case:** Use this as your go-to template for any new product listing. Ideal when launching a product and needing a strong, conversion-focused description from scratch.

```
Write a compelling Shopify product description for [PRODUCT NAME] targeting [TARGET AUDIENCE]. The description should be 150-200 words, lead with the single most powerful benefit (not a feature), use sensory language to help the reader visualize using the product, address the primary pain point it solves, include 3-5 bullet points highlighting key features translated into benefits, and end with a confident call-to-action. Avoid hype words like 'amazing' or 'revolutionary.' Tone: [BRAND TONE: e.g., professional, playful, luxurious]. Price point: [PRICE RANGE].
```

### 2. SEO-Optimized Description with Keywords

**Use case:** Use when you want to rank organically on Google for specific search terms. Best for products in competitive categories where SEO traffic is a priority.

```
Write an SEO-optimized product description for a Shopify store selling [PRODUCT NAME]. Primary keyword: [PRIMARY KEYWORD]. Secondary keywords: [KEYWORD 2], [KEYWORD 3], [KEYWORD 4]. The description should be 200-250 words, naturally incorporate all keywords without stuffing, include an H1-style opening sentence, a benefits-driven body paragraph, a bullet list of 4-6 features, and a closing sentence with a call-to-action. The content must read naturally for human shoppers while being structured for search engine visibility. Product category: [CATEGORY]. Target customer: [TARGET CUSTOMER].
```

### 3. Luxury and Premium Product Description

**Use case:** Perfect for luxury goods, artisan products, premium skincare, high-end fashion, or any product where price positioning and perceived value are critical to the sale.

```
Write a premium, high-end product description for [PRODUCT NAME] priced at [PRICE]. The target buyer is [TARGET AUDIENCE: e.g., affluent professionals aged 35-55]. Use elevated, sophisticated language that communicates exclusivity and craftsmanship without being pretentious. Focus on the quality of materials ([MATERIALS/INGREDIENTS]), the heritage or expertise behind the product, and the lifestyle transformation it offers. The description should be 180-220 words, evoke aspiration and desire, avoid discount language, and position the price as an investment rather than a cost. End with a subtle but confident call-to-action.
```

### 4. Problem-Solution Product Description

**Use case:** Highly effective for products that solve a clear, relatable problem — such as health supplements, organizational tools, tech accessories, or cleaning products. Boosts conversion by creating emotional resonance.

```
Write a problem-solution product description for [PRODUCT NAME] on a Shopify store. Start by vividly describing the frustration or pain point experienced by [TARGET AUDIENCE] when they don't have this product. Use empathetic language that shows you understand their struggle. Then introduce [PRODUCT NAME] as the solution, explaining exactly how it solves the problem using [KEY FEATURE/MECHANISM]. Include 3 specific, measurable outcomes the customer can expect. Add a brief section on who this product is NOT for, to increase credibility. Total length: 200-250 words. Tone: [BRAND TONE].
```

### 5. Short-Form Mobile-First Description

**Use case:** Use for products where mobile traffic dominates, or as a secondary short description displayed above the fold. Great for impulse-buy items, accessories, and everyday consumer goods.

```
Write a punchy, mobile-optimized product description for [PRODUCT NAME] that is no longer than 100 words. Over 60% of shoppers view this on a phone, so every word must earn its place. Use short sentences (maximum 12 words each), no complex vocabulary, one clear value proposition in the first line, 3 micro bullet points (5 words or fewer each), and one direct call-to-action at the end. The product is [BRIEF PRODUCT DESCRIPTION]. Target customer: [TARGET AUDIENCE]. Brand voice: [BRAND VOICE: e.g., bold, friendly, minimal].
```

### 6. Storytelling Narrative Description

**Use case:** Ideal for lifestyle brands, gift products, artisan goods, beauty products, or any item with an emotional purchase driver. Works exceptionally well for brands building a loyal community.

```
Write a story-driven product description for [PRODUCT NAME] that connects emotionally with [TARGET AUDIENCE]. Open with a 2-3 sentence micro-story or scene that places the reader in a relatable moment where this product makes a difference. Transition naturally into the product itself, weaving features into the narrative rather than listing them. The story should make the reader feel something — whether that's comfort, excitement, nostalgia, or confidence. Total length: 220-270 words. Include a short bullet summary at the end for scanners. Product details: [KEY FEATURES/BENEFITS]. Brand tone: [BRAND TONE].
```

### 7. Technical Product Description for Informed Buyers

**Use case:** Use for electronics, tools, fitness equipment, photography gear, or any product purchased by enthusiasts who want full technical details before committing. Reduces pre-purchase questions and returns.

```
Write a detailed, technically accurate product description for [PRODUCT NAME] aimed at knowledgeable buyers who research before purchasing. Target audience: [TARGET AUDIENCE: e.g., photographers, engineers, fitness enthusiasts]. Lead with performance outcomes, then provide specific technical specifications — [SPEC 1], [SPEC 2], [SPEC 3] — explained in terms of what they mean for the user's real-world experience. Use industry-standard terminology where appropriate. Include a compatibility or use-case section. Total length: 250-300 words. Avoid oversimplifying. Tone: authoritative and informative. End with a confidence-building statement about quality or warranty.
```

### 8. Gift Product Description

**Use case:** Essential for Q4 holiday campaigns, Mother's Day, Valentine's Day, or any product that has strong gifting appeal. Reframe the buyer as a hero giving a great gift.

```
Write a gift-focused product description for [PRODUCT NAME] targeting shoppers looking to buy for [GIFT RECIPIENT: e.g., new moms, coffee lovers, fitness enthusiasts]. The description should help the gift-giver feel confident they've found the perfect present. Highlight why this makes a thoughtful gift, what emotion the recipient will feel when they receive it, and the occasions it's suitable for (e.g., birthdays, holidays, anniversaries). Include a 'why they'll love it' bullet list with 4 points. Address gifting practicalities: packaging, personalization options if any ([PERSONALIZATION OPTIONS]), and delivery. Length: 180-220 words. Tone: warm and enthusiastic.
```

### 9. Eco-Friendly and Sustainable Product Description

**Use case:** Use for sustainable, ethical, or natural product lines. Critical for attracting conscious consumers who are skeptical of superficial green marketing claims.

```
Write an eco-conscious product description for [PRODUCT NAME] that appeals to environmentally aware shoppers without greenwashing. Target audience: [TARGET AUDIENCE]. Clearly state the specific sustainability credentials: [SUSTAINABILITY FEATURES: e.g., made from recycled materials, carbon-neutral shipping, biodegradable packaging]. Translate each green feature into a personal benefit for the buyer. Address the 'does it perform as well?' skepticism directly. Use confident, factual language rather than vague terms like 'eco-friendly' or 'green.' Length: 200-240 words. Include a short statement about the brand's broader environmental mission. End with an empowering call-to-action that makes the buyer feel their purchase makes a difference.
```

### 10. Before-and-After Transformation Description

**Use case:** Extremely powerful for beauty, skincare, weight loss, fitness, home improvement, or any product promising a visible or felt transformation. One of the highest-converting frameworks for results-driven products.

```
Write a transformation-focused product description for [PRODUCT NAME] using a before-and-after framework. Describe in 2-3 sentences what life, appearance, or experience looks like BEFORE using this product for [TARGET AUDIENCE]. Then vividly describe the transformation AFTER using [PRODUCT NAME] — be specific, sensory, and aspirational. Bridge the gap by explaining HOW the product creates this transformation using [KEY MECHANISM/INGREDIENTS/FEATURES]. Include 4 specific results or outcomes as bullet points. Add a brief social proof line: [SOCIAL PROOF ELEMENT: e.g., 'Over 10,000 customers have experienced...']. Length: 200-250 words. Tone: [BRAND TONE].
```

### 11. Comparison and Differentiation Description

**Use case:** Use when entering a crowded market or when your product has a genuine innovation that customers need to understand. Helps skeptical repeat-purchasers of competitor products switch to your brand.

```
Write a product description for [PRODUCT NAME] that clearly differentiates it from conventional alternatives without naming competitors. Target audience: [TARGET AUDIENCE] who has likely tried [COMMON ALTERNATIVE: e.g., 'generic supplements,' 'traditional tools,' 'fast fashion']. Acknowledge what the customer may have experienced with standard options, then explain the 3 specific ways [PRODUCT NAME] is different and better: [DIFFERENTIATOR 1], [DIFFERENTIATOR 2], [DIFFERENTIATOR 3]. Use confident, factual language. Include a 'What makes us different' mini-section. Length: 220-260 words. Avoid disparaging competitors. End with a risk-reducing statement such as a guarantee or free returns policy: [GUARANTEE DETAILS].
```

### 12. Urgency and Scarcity-Driven Description

**Use case:** Use for limited edition products, seasonal items, handmade goods with limited inventory, or during promotional periods. Effective when scarcity is real and honest.

```
Write a product description for [PRODUCT NAME] that incorporates legitimate urgency and scarcity without being manipulative or dishonest. Target audience: [TARGET AUDIENCE]. Include the standard benefit-focused description (150 words covering the top 3 benefits, key features as bullets, and the core value proposition), then add a closing urgency section that authentically communicates: [SCARCITY REASON: e.g., limited batch production, seasonal availability, high demand]. The urgency language should feel informative rather than pressuring. Suggest what the customer risks missing out on if they delay. End with a decisive call-to-action. Total length: 200-240 words. Tone: [BRAND TONE].
```

### 13. Bundle and Multi-Product Description

**Use case:** Use when creating starter kits, gift sets, or curated product bundles. Increases average order value by clearly communicating the superior value of buying together.

```
Write a product description for a bundle or kit called [BUNDLE NAME] that includes: [PRODUCT 1], [PRODUCT 2], [PRODUCT 3], and [PRODUCT 4]. Target audience: [TARGET AUDIENCE]. The description should explain the unified benefit of the complete bundle (not just list the items), show how the products work together as a system, highlight the value compared to buying separately (savings: [SAVINGS AMOUNT OR PERCENTAGE]), and answer the question 'why do I need all of these?' for a skeptical buyer. Include a bullet list of what's included with one-line benefit descriptions for each item. Length: 220-270 words. Tone: helpful and value-focused.
```

### 14. Social Proof-Led Description

**Use case:** Use for products in markets where skepticism is high — supplements, skincare, investment tools, or any category flooded with competitors making similar claims. Trust signals are your primary conversion lever.

```
Write a product description for [PRODUCT NAME] that leads with social proof and customer validation to build immediate trust. Open with a powerful customer result or testimonial paraphrase (do not fabricate — use this placeholder result: [KEY CUSTOMER RESULT: e.g., '85% of users reported noticeable results within 2 weeks']). Follow with a credibility statement about the brand or product: [CREDIBILITY ELEMENT: e.g., number of customers, years in business, certifications]. Then deliver the core product description covering the top 3 benefits and key features. Close with a community or belonging statement that makes the buyer feel they're joining something. Length: 200-250 words. Target audience: [TARGET AUDIENCE]. Tone: trustworthy and warm.
```

### 15. Minimalist Premium Description

**Use case:** Designed for minimalist, design-led, or luxury brands where less copy signals more confidence. Works beautifully for lifestyle products, premium accessories, skincare, and home goods.

```
Write a minimalist product description for [PRODUCT NAME] using no more than 120 words total. The brand aesthetic is clean, modern, and confident — like [BRAND REFERENCE: e.g., Apple, Muji, Aesop]. Every sentence must be purposeful. Use short, declarative statements. No bullet points — flowing prose only. Focus on one core benefit, one standout material or feature, and one lifestyle statement. The product is [BRIEF PRODUCT DESCRIPTION]. Price: [PRICE]. Target audience: [TARGET AUDIENCE]. Do not use exclamation marks. Do not use words like 'perfect,' 'amazing,' or 'unique.' The copy should feel like it belongs in a design magazine. End with the product name as the call-to-action anchor.
```

### 16. FAQ-Integrated Product Description

**Use case:** Use for products that receive repetitive customer questions or where buyer hesitation is high. Reduces customer service load and prevents shoppers from leaving to 'do more research.'

```
Write a product description for [PRODUCT NAME] that seamlessly integrates answers to the top buyer objections and questions. Target audience: [TARGET AUDIENCE]. First, write a 120-word benefit-focused opening description. Then add a 'Quick Answers' section that addresses these specific concerns in 2-3 sentences each: (1) [OBJECTION/QUESTION 1: e.g., 'Will this work for my skin type?'], (2) [OBJECTION/QUESTION 2: e.g., 'How long until I see results?'], (3) [OBJECTION/QUESTION 3: e.g., 'Is this safe to use daily?']. Keep answers confident and specific, not vague. This format reduces cart abandonment by eliminating the need to search for answers elsewhere. End with a reassuring call-to-action. Total length: 280-320 words.
```

### 17. Seasonal and Holiday-Themed Description

**Use case:** Use to refresh product descriptions seasonally to improve relevance and conversion during peak shopping periods. A seasonal description feels more immediate and motivates faster purchase decisions.

```
Write a [SEASON/HOLIDAY: e.g., Summer, Christmas, Back-to-School]-themed product description for [PRODUCT NAME] that feels timely and relevant without being clichéd. Target audience: [TARGET AUDIENCE]. Connect the product naturally to the seasonal moment — how does it fit into what the customer is doing, feeling, or needing right now during [SEASON/HOLIDAY]? Include seasonal sensory language that creates atmosphere. Highlight any limited-time packaging, seasonal variants, or special offers: [SEASONAL OFFER]. Keep the core product benefits intact but wrapped in seasonal context. Length: 180-220 words. Tone: [BRAND TONE]. This description will be used from [START DATE] to [END DATE].
```

### 18. Health and Wellness Product Description

**Use case:** Essential for supplement brands, wellness products, and health devices that must balance compelling copy with regulatory compliance. Avoids legal risk while still converting health-conscious buyers.

```
Write a compliant, benefit-focused product description for [PRODUCT NAME: e.g., supplement, wellness device, fitness tool] targeting [TARGET AUDIENCE]. Important: Use outcome-oriented language without making unverified medical claims. Instead of 'cures' or 'treats,' use language like 'supports,' 'may help,' 'designed to,' or 'formulated to.' Include: the wellness goal this product supports ([WELLNESS GOAL: e.g., better sleep, joint mobility, immune support]), key active ingredients or features with their functional roles ([INGREDIENT/FEATURE + ROLE]), the daily routine or usage instructions, and who this is ideal for. Add a brief disclaimer section. Length: 220-260 words. Tone: knowledgeable, caring, science-respecting.
```

### 19. Kids and Family Product Description

**Use case:** Use for toys, children's clothing, educational products, or family-focused items. Remember: parents buy with their head (safety, value, quality) but also their heart (joy, connection, development).

```
Write a product description for [PRODUCT NAME] targeting parents shopping for [CHILD AGE RANGE: e.g., toddlers aged 2-4, kids aged 6-12]. The real buyer is the parent, but the end user is the child. Address the parent's priorities first: safety ([SAFETY CERTIFICATIONS]), educational or developmental value ([DEVELOPMENTAL BENEFIT]), durability, and ease of cleaning or use. Then describe why kids will love it — the fun, the engagement, the play value. Use warm, reassuring language that helps the parent feel they're making a great choice for their child. Avoid anything that could imply risk. Include age-appropriateness guidance. Length: 200-240 words. Tone: friendly, reassuring, enthusiastic.
```

### 20. Subscription Product Description

**Use case:** Use for subscription boxes, SaaS-style physical products, replenishment subscriptions, or any recurring purchase model. Must overcome the psychological barrier of ongoing commitment.

```
Write a product description for [SUBSCRIPTION PRODUCT NAME], a [FREQUENCY: e.g., monthly, weekly] subscription box or service for [TARGET AUDIENCE]. The description must sell the subscription model, not just the product. Highlight: the convenience and time-saving benefit, the discovery or curation value, the financial savings vs. buying individually (savings: [SAVINGS AMOUNT]), the flexibility and cancellation policy ([SUBSCRIPTION TERMS]), and what the customer receives each [FREQUENCY]. Create a sense of anticipation and ongoing delight. Address the commitment hesitation directly with a brief risk-reversal statement. Length: 220-260 words. Include a 'What you get' bullet list. Tone: excited, trustworthy, value-forward.
```

### 21. Upsell and Cross-Sell Product Description

**Use case:** Use on product pages, cart pages, or in post-purchase email sequences to increase average order value. Works best when the upsell genuinely enhances the use of the original product.

```
Write a product description for [UPSELL PRODUCT NAME] that is designed to be shown to customers who already have or are buying [BASE PRODUCT NAME]. The description should assume the reader is already a customer or fan of the base product and explain why [UPSELL PRODUCT NAME] is the natural next step. Use language like 'takes your [BASE PRODUCT] experience to the next level' or 'the perfect companion to [BASE PRODUCT].' Highlight compatibility, enhanced results when used together, and the incremental value. Length: 150-180 words. Do not re-sell the base product. Tone: familiar, upgrade-focused. Include a clear call-to-action that feels like a logical next step, not a hard sell.
```

### 22. International and Multicultural Audience Description

**Use case:** Use for brands selling internationally or across multiple English-speaking regions. Ensures your copy doesn't accidentally exclude or confuse customers in different markets.

```
Write a product description for [PRODUCT NAME] in clear, globally accessible English that avoids idioms, cultural references, slang, or humor that may not translate well to international audiences. Target markets: [TARGET MARKETS: e.g., US, UK, Australia, Canada, Singapore]. The description should be universally understood, use metric and imperial measurements where relevant ([MEASUREMENTS]), reflect inclusive imagery in language, and avoid assumptions about lifestyle, diet, or cultural norms. Core benefits: [TOP 3 BENEFITS]. Key features: [TOP 3 FEATURES]. Length: 180-220 words. Tone: clear, professional, warm. This description will be used across multiple regional Shopify storefronts.
```

### 23. Relaunch or Updated Product Description

**Use case:** Use when relaunching an improved product, releasing a new version, or reformulating an existing product. Bridges the trust of your existing customer base with the excitement of a new release.

```
Write a product description for the newly updated version of [PRODUCT NAME] — now called [NEW VERSION NAME or 'Version 2.0']. This is a relaunch description for existing customers who may know the original product and new customers discovering it for the first time. Acknowledge the product's proven track record: [LEGACY PROOF POINT: e.g., 'Trusted by 50,000+ customers since 2019']. Then clearly communicate what's new and better: [NEW FEATURE 1], [NEW FEATURE 2], [NEW FEATURE 3]. For existing customers, explain why upgrading is worth it. For new customers, establish why this is the definitive version to buy. Length: 220-260 words. Tone: confident, forward-looking, appreciative of loyal customers.
```

### 24. Budget-Conscious Value Product Description

**Use case:** Use for mid-to-low price point products where the buyer is weighing cost carefully. Reframes affordability as smart shopping rather than cutting corners.

```
Write a product description for [PRODUCT NAME] priced at [PRICE] that appeals to value-conscious shoppers without making the product feel cheap. Target audience: [TARGET AUDIENCE] who cares about getting the best return on their money. Lead with what the customer gets for the price — quantity, quality, or longevity. Use comparison math if helpful: [VALUE COMPARISON: e.g., 'Less than $1 per use']. Emphasize quality features that justify the purchase without seeming defensive. Use confident, proud language — this is affordable excellence, not a compromise. Include a 'What's included' section. Add a brief statement on quality assurance or guarantee: [GUARANTEE]. Length: 180-220 words. Tone: direct, honest, empowering.
```

### 25. A/B Test Variant Description

**Use case:** Use when you're unsure whether your audience responds better to logical or emotional appeals. Run both as an A/B test on your Shopify theme to determine which drives higher conversion before committing to one version.

```
I need two different product description versions for split testing on my Shopify store. Product: [PRODUCT NAME]. Target audience: [TARGET AUDIENCE]. Version A should use a FEATURES-FIRST approach: start with the most impressive technical specification or ingredient, build credibility through detail, and appeal to analytical buyers who want to know 'what is it?' Version B should use an EMOTIONS-FIRST approach: start with a feeling or lifestyle outcome, use sensory and aspirational language, and appeal to emotional buyers who want to know 'how will it make me feel?' Both versions should be 150-180 words, include the same core information ([KEY FEATURES: [FEATURE 1], [FEATURE 2], [FEATURE 3]]), and end with a call-to-action. Label them clearly as VERSION A and VERSION B.
```
